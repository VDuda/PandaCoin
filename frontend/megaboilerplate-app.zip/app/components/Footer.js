import React from 'react';

class Footer extends React.Component {
  render() {
    return (
      <footer>
        <p>© 2016 Company, Inc. All Rights Reserved.</p>
      </footer>
    );
  }
}

export default Footer;
